#include"Quizzer.h"
using namespace std;

//////FUNCTION PROTOTYPES//
void interface();
int math();
void personality();

/////////////MAIN///////////
int main()
{
    user u;
    string user;
    string pass;
    cout<<"\t\t___________________________"<<endl;
    cout<<"\t\t Q U E S T I O N - A T O R "<<endl;
    cout<<"\t\t___________________________"<<endl<<endl<<endl;
    cout<<"  | 1.CONTINUE AS A GUEST |";
    cout<<"  |2.CREATE AN ACCOUNT |";
    cout<<"  | 3.LOGIN |"<<endl;
    int b;
    cin>>b;
  if(b==1)
  {
      cout<<"WELCOME USER!"<<endl;
      system("pause");
      interface();
  }
  if (b==2)
  {
      u.Register();
  }
  if (b==3)
  {
   u.login_page();
  }
return 0;
}

