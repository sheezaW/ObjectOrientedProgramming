#ifndef QUIZZER_H
#define QUIZZER_H

#include <iostream>
#include<cstdlib>
#include<ctime>
#include<conio.h>
#include<cmath>
#include <fstream>
using namespace std;

typedef double type;

//////FUNCTION PROTOTYPES//
void interface();
int math();
void personality();

class Quizzer //Parent Class
{
    protected:
        ////VARIABLES
        type a;
        type b;
        int ans;
    public:
        Quizzer(); //empty constructor

        ////FUNCTIONS
        friend void interface();
        friend int math();
        friend  void personality();
        virtual void response(bool test) = 0;


        //Destructor
        virtual ~Quizzer();
};
class Questioneer: public Quizzer //Child Class
{
private:
    double tries;

public:
    int choice;
    int difficulty;

    Questioneer(int,int); //Child constructor

    void Asker();
    void randomizer();
    void response(bool );

    void Add();
    void Sub();
    void Mult();
    void Div();
    void Mod();
    void Mix();

    bool Check(int);

    ~Questioneer(); //Child destructor
};

class user
{
    public:
        string username;
        string password;
        string xuser;
        string xpass;
        ifstream xFile;
        ofstream cFile;
    //FUNCTIONS//
    void Register()
    {
        xFile.open("login.txt");
        cFile.open("login.txt");
        cout<<"Register"<<endl;
        cout<<"Username: ";
        cin>>username;
        cout<<"Password: ";
        cin>>password;
        cFile << username << endl;
        cFile << password << endl;
        system("CLS");
        int atempts=0;
        bool s=true;
        while(s==true)
        {
            cout<<"Login"<<endl;
            cout<<"Username: ";
            cin>>xuser;
            cout<<"Password: ";
            cin>>xpass;
            if(username == xuser && password==xpass)
            {
                cout<<"login successful!"<<endl;
                s=false;
                system("pause");
                interface();
            }
            else
            {
                cout<<"try again"<<endl;
                atempts++;
                if (atempts>1)
                {
                    cout<<"too many failed attempts!"<<endl;
                    s=false;
                    exit(0);
                }
                else
                    continue;
            }
        }
    xFile.close();
    cFile.close();
    }
    void login_page()
    {
        string search,user,line,pass;
        bool t=false;
        while(t==false)
        {
            cout<<"enter username:"<<endl; cin>>user; cout<<"enter password:";cin>>pass;
            search=user;

            ifstream inFile;
            inFile.open("login.txt");
            size_t pos;
            while(inFile.good())
            {
              getline(inFile,line); // get line from file
              pos=line.find(search); // search
              if(pos!=string::npos) // string::npos is returned if string is not found
                {
                    cout <<"Found!"<<endl<<endl<<endl;
                    cout<<"WELCOME "<<search<<endl;
                    t=true;
                    system("pause");
                    interface();
                }
                else
                {
                    cout<<"not found, try again!"<<endl;
                    break;
                }
            }
        }
    }
};

#endif // QUIZZER_H
