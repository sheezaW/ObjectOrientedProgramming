#include "Quizzer.h"

//Global variables and functions//
int correct=0;

////Function prototypes////
void interface();
int math();
void personality();

//////PARENT CLASS/ BASE CLASS STARTS HERE///////////////////

Quizzer::Quizzer() //constructor
{
    a=0;
    b=0;
    ans=0;
}
Quizzer::~Quizzer() //destructor
{

}

//////////CHILD CLASS STARTS HERE/////////////////

Questioneer::Questioneer(int ch, int dif): choice(ch), difficulty(dif)//child constructor
{
    //use exception handling to determine if wrong choice or diff

}
void Questioneer::Asker()
{
    randomizer();

    switch (choice)
    {
        case 1: Add();break;
        case 2: Sub();break;
        case 3: Mult();break;
        case 4: Div();break;
        case 5: Mod();break;
        case 6: Mix();break;

    }
}
void Questioneer::randomizer() //randomizes the values
{
    srand(static_cast<unsigned int>(time(0)));
    switch(difficulty)
    {
        case 1:   a=rand()%10;   b=rand()%10; break;
        case 2:   a=rand()%100;   b=rand()%100; break;
        case 3:   a=rand()%1000;   b=rand()%1000; break;
        default:  a=rand()%10;   b=rand()%10;cout<<"Since you chose the wrong difficulty, now you can only play on EASY!"<<endl;
    }
}

/////////////Math functions begin/////////////////
void Questioneer::Add()
{
    cout<<a<<" + "<<b<<" = ";
    ans=a+b;
}

void Questioneer::Sub()
{
    cout<<a<<" - "<<b<<" = ";
    ans=a-b;
}

void Questioneer::Mult()
{
    cout<<a<<" * "<<b<<" = ";
    ans=a*b;
}

void Questioneer::Mod()
{
    cout<<a<<" % "<<b<<" = ";
    ans=int(a)%int(b);
}

void Questioneer::Div()
{
    do
    {
        randomizer();
        cout<<"calculating......";
    }
    while(!(a!=0 && b!=0));
    cout<<a<<" / "<<b<<" = ";
    ans=round(a/b);
}

void Questioneer::Mix()
{
    int random;
    random=1+rand() % 6;
    switch(random)
    {
        case 1: Add();break;
        case 2: Sub();break;
        case 3: Mult();break;
        case 4: Div();break;
        case 5: Mod();break;
    }
}

//////CALCULATOR FUNCTIONS////

bool Questioneer::Check(int Uans) //Checker
{

    if (ans==Uans)
        return true;
    else
        return false;
}

void Questioneer::response(bool test)
 {
    int x=1+(rand()%4);
    if (test)
        switch (x)
        {
        case 1:cout<<"Very Good!"<<endl;break;
        case 2:cout<<"Excellent!"<<endl;break;
        case 3:cout<<"Keep it up!"<<endl;break;
        case 4:cout<<"Nice work!"<<endl;break;
        }
    else
        switch (x)
        {
        case 1:cout<<"No. Please try again."<<endl;break;
        case 2:cout<<"Wrong. Try again."<<endl;break;
        case 3:cout<<"Don't give up! Try again."<<endl;break;
        case 4:cout<<"No. Keep trying!"<<endl;break;
        }
    }

Questioneer::~Questioneer()
{
    //child destructor
}

/////FRIEND FUNCTIONS////
void interface()//when user enters
{
    int a;
    system("cls");
    cout<<"\t\t___________________________"<<endl;
    cout<<"\t\t Q U E S T I O N - A T O R "<<endl;
    cout<<"\t\t___________________________"<<endl<<endl<<endl;
    cout<<"\tchoose:"<<endl;
    cout<<"\t1- Math quiz"<<endl;
    cout <<"\t2- Personality quiz"<<endl;
    cin>>a;
    if(a==1)
        math();
    if(a==2)
        personality();
}

void personality()
{
    system("cls");
	int E,I,N;
	E=0;
	I=0;
	N=0;
	char ch1[100];
	char ch;
	cout<<"\t-------------------------"<<endl;
	cout<<"\t P E S O N A L I T Y TEST"<<endl;
	cout<<"\t-------------------------"<<endl;
	cout<<"\nTHERE WILL BE 6 QUESTIONS \nFind out if you are an Extrovert, Introvert or stand somewhere between both"<<endl;
	cout<<"\n\nEnter Your Name"<<endl;
	cin>>ch1;

	system("cls");
	cout<<"	Welcome "<<ch1<<endl;
	cout<<" Enter your answer in form of 'a','b' and 'c' only."<<endl;

	cout<<"QUESTION 1:What seems more interesting to you?"<<endl;
	cout<<"a) Enjoying your fav novel in a cozy place"<<endl; //[introvert]
    cout<<"b) Meeting your best friend at your favorite coffee shop"<<endl; //[extrovert]
    cout<<"c) Depends on mood"<<endl; //[the neutral option]

    do
    {
        cout<<"Your answer:";
        cin>>ch;
        if(ch=='a')
            I=I+10;
        else if(ch=='b')
            E=E+10;
        else if(ch=='c')
            N=N+10;
        else
        cout<<"Sorry Wrong Answer, Try again"<<endl;
    }
    while(!(ch=='a'||ch=='b'||ch=='c'));

	system("cls");
	cout<<"QUESTION 2: When you meet with new people"<<endl;
	cout<<"a) You enjoy meeting new people and being social"<<endl; //[extrovert]
    cout<<"b) You are interested in meeting new people but you are uncomfortable in the beginning at least"<<endl; //[introvert]
    cout<<"c) You only enjoy meeting new people if you find common interests"<<endl; //[neutral]

    do
    {
        cout<<"Your answer:";
        cin>>ch;
        if(ch=='a')
            E=E+10;
        else if(ch=='b')
            I=I+10;
        else if(ch=='c')
            N=N+10;
        else
    cout<<"Sorry Wrong Answer, Try again"<<endl;
    }
    while(!(ch=='a'||ch=='b'||ch=='c'));

	system("cls");
	cout<<"QUESTION 3: If you have to talk about yourself"<<endl;
	cout<<"a) You love that others know you"<<endl; //[extrovert]
    cout<<"b) You feel embarrassed and find it awkward"<<endl; //[introvert]
    cout<<"c) It depends on situation whether you are okay with it"<<endl; //[neutral]


    do
    {
        cout<<"Your answer:";
        cin>>ch;
        if(ch=='a')
            E=E+10;
        else if(ch=='b')
            I=I+10;
        else if(ch=='c')
            N=N+10;
        else
        cout<<"Sorry Wrong Answer, Try again"<<endl;
        }
    while(!(ch=='a'||ch=='b'||ch=='c'));

	system("cls");
	cout<<"QUESTION 4: When entering a room full of people"<<endl;
	cout<<"a) You want everyone to notice you"<<endl; //[E]
    cout<<"b) You wish to pass unnoticed "<<endl; //[I]
    cout<<"c) It does not matter to you if people notice or not"<<endl; //[N]

    do
    {
        cout<<"Your answer:";
        cin>>ch;
        if(ch=='a')
            I=I+10;
        else if(ch=='b')
            E=E+10;
        else if(ch=='c')
            N=N+10;
        else
        cout<<"Sorry Wrong Answer, Try again"<<endl;
    }
    while(!(ch=='a'||ch=='b'||ch=='c'));

	system("cls");
	cout<<"QUESTION 5: Around unknown people"<<endl;
	cout<<"a) You only talk when necessary"<<endl; //[N]
    cout<<"b) You like being social and ask many questions about them "<<endl; //[E]
    cout<<"c) You feel anxious"<<endl; //[I]

    do
    {
        cout<<"Your answer:";
        cin>>ch;
        if(ch=='a')
             N=N+10;
        else if(ch=='b')
            E=E+10;
        else if(ch=='c')
           I=I+10;
        else
        cout<<"Sorry Wrong Answer, Try again"<<endl;
    }
    while(!(ch=='a'||ch=='b'||ch=='c'));

	system("cls");
	cout<<"QUESTION 6: In the presence of a group of people"<<endl;
	cout<<"a) You prefer not to attract attention"<<endl; //[I]
    cout<<"b) You want to be the center of attention "<<endl; //[E]
    cout<<"c) You try to remain unnoticed as you mind your impression a lot"<<endl; //[N]

    do
    {
        cout<<"Your answer:";
        cin>>ch;
        if(ch=='a')
            I=I+10;
        else if(ch=='b')
            E=E+10;
        else if(ch=='c')
            N=N+10;
        else
        cout<<"Sorry Wrong Answer, Try again"<<endl;
    }
    while(!(ch=='a'||ch=='b'||ch=='c'));

	system("cls");
    if(E >= I && E >= N)
    {
        cout << "You are more of an Extrovert "<<endl;
        ofstream file;
        file.open ("display.txt",ios::out | ios::app);
        file<<" "<<ch1<<": "<<"You are more of an Extrovert "<<"\n";
        file.close();
    }

    if(I >= E && I >= N)
    {
        cout << "You are more of an Introvert "<<endl;
        ofstream file;
        file.open ("display.txt",ios::out | ios::app);
        file<<" "<<ch1<<": "<<"You are more of an Introvert "<<"\n";
        file.close();
    }
    if(N >= E && N >= I)
    {
        cout << "Your personality is a mix of an Extrovert and an Introvert"<<endl;
        ofstream file;
        file.open ("display.txt",ios::out | ios::app);
        file<<" "<<ch1<<": "<<"Your personality is a mix of an Extrovert and an Introvert"<<"\n";
        file.close();
    }
    cout<<"\n\n\n1.PROCEED TO MAIN MENU \n2.EXIT"<<endl;
    int y;
    cin>>y;
    if (y==1)
    {
        system("cls");
        interface();
    }
    if(y==2)
    {
        exit(0);
    }
}

int Difficulty() //choose difficulty
{
    int dif;
    system("cls");
    cout<<"Choose difficulty:"<<endl
    <<"\t1-Easy"<<endl
    <<"\t2-Medium"<<endl
    <<"\t3-Hard"<<endl
    <<"Your choice: ";
    cin>>dif;
    return dif;
}

int Choicer() //choose what to ask
{
    int ch;
    system("cls");
    cout<<"What do you want to be tested on?"<<endl
    <<"1- Addition"<<endl
    <<"2- Subtraction"<<endl
    <<"3- Multiplication"<<endl
    <<"4- Division"<<endl
    <<"5- Modulus"<<endl
    <<"6- Mix of all 5"<<endl
    <<"Your choice: ";
    cin>>ch;
    if (ch == 4 || ch == 6)
    {
        cout<<"Please input answers in round off values!"<<endl;
    }
    return ch;
}

int math()
{
    int User_ans;
    Questioneer obj(Choicer(),Difficulty());

    for (int i = 0; i<5; i++)
    {
        system("cls");
        obj.Asker();
        int tries=0;

       do
        {
            cin>>User_ans;
            if (obj.Check(User_ans))
            {
                obj.response(true);//right
                correct++;
                system("pause");
                break;
            }
            else
            {
                if (tries == 2)
                {
                    cout<<"OUT OF TRIES!"<<endl;
                    break;
                }
                obj.response(false);//wrong
            }
            tries++;
        }
        while(!User_ans);
    }
    char x;
    cout<<"YOU GOT "<<correct<<" OUT OF  5"<<endl;
    system("pause");
    system("cls");

    ofstream file;
  file.open ("display.txt", ios::out | ios::app );
  file<<"\nmaths score "<<correct<<"\n";
  file.close();
    cout<<"DO YOU WANT TO CONTINUE(Y/N): "<<endl;
    cin>>x;
    if(x=='y' || x=='Y')
        {
            system("cls");
            interface();
        }
    if(x=='n'||x=='N')
        {
            cout<<"Thank you for playing with us"<<endl;
            cout<<"Your final result has been updated in the database, please check the DISPLAY.TXT file "<<endl;
        }
        exit(0);
}

